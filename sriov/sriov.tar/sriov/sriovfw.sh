mstflint -d 3b:00.0 q | grep FW
